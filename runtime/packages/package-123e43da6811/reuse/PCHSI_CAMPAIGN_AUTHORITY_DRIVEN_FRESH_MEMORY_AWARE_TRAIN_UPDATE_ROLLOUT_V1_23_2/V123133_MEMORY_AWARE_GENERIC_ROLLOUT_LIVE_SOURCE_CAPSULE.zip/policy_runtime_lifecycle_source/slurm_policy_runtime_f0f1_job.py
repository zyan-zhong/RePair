#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, subprocess, time
from pathlib import Path
from policy_runtime_service import write_once
from policy_runtime_slurm_execution import validate_execution_contract, validate_slurm_environment


def main(argv=None):
    ap=argparse.ArgumentParser(); ap.add_argument('--execution-contract',required=True); a=ap.parse_args(argv)
    contract_path=Path(a.execution_contract).resolve(); contract=json.loads(contract_path.read_text('utf-8')); validate_execution_contract(contract)
    try:
        import torch
        cuda_count=torch.cuda.device_count() if torch.cuda.is_available() else 0
        cuda_names=[torch.cuda.get_device_name(i) for i in range(cuda_count)]
    except Exception as exc:
        raise SystemExit('STOP=CUDA_RUNTIME_PROBE_FAILED:'+type(exc).__name__)
    att=validate_slurm_environment(contract,os.environ,cuda_device_count=cuda_count); att['cuda_device_names']=cuda_names; att['timestamp_unix']=time.time()
    root=Path(str(contract['execution_root'])); start=root/'POLICY_RUNTIME_SLURM_F0F1_JOB_START_V1.json'
    if start.exists(): raise SystemExit('STOP=SLURM_JOB_START_RECEIPT_EXISTS')
    write_once(start,att)
    cmd=[str(contract['python_executable']),'-B',str(Path(str(contract['package_root']))/'run_policy_runtime_service_contract_f0f1.py'),'--source-integration-root',str(contract['source_integration_root']),'--retry-integration-root',str(contract['retry_integration_root']),'--repo',str(contract['repo']),'--python',str(contract['python_executable']),'--launch-contract',str(contract['launch_contract_path']),'--service-ready-timeout-seconds',str(contract['service_ready_timeout_seconds']),'--branch-operational-timeout-seconds',str(contract['branch_operational_timeout_seconds']),'--termination-grace-seconds',str(contract['termination_grace_seconds']),'--approval','EXECUTION_APPROVED_CURRENT_RUNTIME_SERVICE_CONTRACT_AND_F0F1_RECOVERY_V1']
    cp=subprocess.run(cmd,check=False)
    terminal={'schema_id':'POLICY_RUNTIME_SLURM_F0F1_JOB_TERMINAL_V1','schema_version':1,'status':'COMPLETED' if cp.returncode==0 else 'FAILED','returncode':cp.returncode,'slurm_job_id':att['slurm_job_id'],'slurm_job_partition':att['slurm_job_partition'],'slurm_job_nodelist':att['slurm_job_nodelist'],'expected_gpu_count':att['expected_gpu_count'],'tensor_parallel_size':att['tensor_parallel_size'],'execution_contract_sha256':contract['execution_contract_sha256'],'scientific_failure_label_created':False,'automatic_resubmit_authorized':False,'timestamp_unix':time.time()}
    path=root/'POLICY_RUNTIME_SLURM_F0F1_JOB_TERMINAL_V1.json'
    if path.exists(): raise SystemExit('STOP=SLURM_JOB_TERMINAL_RECEIPT_EXISTS')
    write_once(path,terminal)
    print(json.dumps(terminal,indent=2,sort_keys=True)); return cp.returncode

if __name__=='__main__': raise SystemExit(main())
