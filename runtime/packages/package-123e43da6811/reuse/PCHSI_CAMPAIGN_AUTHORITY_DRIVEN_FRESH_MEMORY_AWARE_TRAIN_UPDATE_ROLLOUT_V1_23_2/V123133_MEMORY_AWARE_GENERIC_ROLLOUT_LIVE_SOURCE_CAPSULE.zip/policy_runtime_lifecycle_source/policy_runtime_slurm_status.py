#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, subprocess
from pathlib import Path


def main(argv=None):
    ap=argparse.ArgumentParser(); ap.add_argument('--execution-root',required=True); a=ap.parse_args(argv)
    root=Path(a.execution_root).resolve(); receipt=json.loads((root/'POLICY_RUNTIME_SLURM_SUBMISSION_RECEIPT_V1.json').read_text('utf-8')); job_id=receipt.get('slurm_job_id')
    if not isinstance(job_id,str) or not job_id: raise SystemExit('STOP=SLURM_JOB_ID_MISSING')
    cp=subprocess.run(['sacct','-j',job_id,'--format=JobIDRaw,State,ExitCode,Elapsed,NodeList,Partition,AllocTRES','-P','-n'],capture_output=True,text=True,check=False)
    terminal_path=root/'POLICY_RUNTIME_SLURM_F0F1_JOB_TERMINAL_V1.json'
    terminal=json.loads(terminal_path.read_text('utf-8')) if terminal_path.is_file() else None
    report={'schema_id':'POLICY_RUNTIME_SLURM_STATUS_V1','schema_version':1,'slurm_job_id':job_id,'sacct_returncode':cp.returncode,'sacct_stdout':cp.stdout,'sacct_stderr':cp.stderr,'job_terminal_receipt_present':terminal is not None,'job_terminal':terminal,'scientific_actions_performed_by_status_probe':0}
    print(json.dumps(report,indent=2,sort_keys=True)); return 0

if __name__=='__main__': raise SystemExit(main())
