from __future__ import annotations
import hashlib, json


def _canon(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode()


def validate_engine_profile_receipt(profile: dict[str, object], runtime: dict[str, object]) -> dict[str, object]:
    if not isinstance(profile, dict) or not isinstance(runtime, dict):
        raise TypeError("profile/runtime must be dict")
    if profile.get("schema_id") != "POLICY_RUNTIME_COMPATIBLE_ENGINE_PROFILE_DISCOVERY_V1":
        raise ValueError("engine profile schema mismatch")
    if profile.get("schema_version") != 1 or profile.get("status") != "RESOLVED_UNIQUE_COMPATIBLE_POLICY_ENGINE_PROFILE":
        raise ValueError("engine profile not resolved")
    if profile.get("base_model_local_path") != runtime.get("base_model_local_path"):
        raise ValueError("engine profile base model differs from current runtime")
    if profile.get("vllm_version") != runtime.get("vllm_version"):
        raise ValueError("engine profile vLLM version differs from current runtime")
    if profile.get("historical_endpoint_or_alias_reused") is not False:
        raise ValueError("historical endpoint/alias reuse forbidden")
    if profile.get("operator_launch_knobs_synthesized") is not False:
        raise ValueError("operator launch knob synthesis forbidden")
    if profile.get("scientific_candidate_reselection_performed") is not False:
        raise ValueError("scientific candidate reselection forbidden")
    fields=("dtype","tensor_parallel_size","generation_config","chat_template_content_format","request_id_headers_enabled")
    material={name:profile.get(name) for name in fields}
    if not isinstance(material["dtype"],str) or not material["dtype"]:
        raise ValueError("engine profile dtype invalid")
    if type(material["tensor_parallel_size"]) is not int or material["tensor_parallel_size"] <= 0:
        raise ValueError("engine profile tensor parallel size invalid")
    if not isinstance(material["generation_config"],str) or not material["generation_config"]:
        raise ValueError("engine profile generation config invalid")
    if material["chat_template_content_format"] is not None and not isinstance(material["chat_template_content_format"],str):
        raise ValueError("engine profile chat-template format invalid")
    if type(material["request_id_headers_enabled"]) is not bool:
        raise ValueError("engine profile request-id flag invalid")
    expected=hashlib.sha256(b"POLICY_RUNTIME_COMPATIBLE_ENGINE_PROFILE_V1\0"+_canon(material)).hexdigest()
    if profile.get("engine_profile_sha256") != expected:
        raise ValueError("engine profile hash mismatch")
    return dict(profile)
