#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from policy_runtime_service import derive_runtime_authority, write_once
from policy_runtime_engine_profile import build_current_runtime_service_launch_contract
from policy_runtime_engine_profile_receipt import validate_engine_profile_receipt


def main(argv=None):
    ap=argparse.ArgumentParser(); ap.add_argument('--integration-root',required=True); ap.add_argument('--engine-profile',required=True); ap.add_argument('--python',default=sys.executable); ap.add_argument('--output',required=True); a=ap.parse_args(argv)
    runtime=derive_runtime_authority(Path(a.integration_root))['runtime_binding']
    profile=json.loads(Path(a.engine_profile).read_text('utf-8'))
    profile=validate_engine_profile_receipt(profile,runtime)
    contract=build_current_runtime_service_launch_contract(runtime,profile,python_executable=a.python)
    out=Path(a.output)
    if out.exists() or out.is_symlink(): raise SystemExit('STOP=POLICY_RUNTIME_SERVICE_LAUNCH_CONTRACT_EXISTS')
    write_once(out,contract)
    print(json.dumps({'status':contract['status'],'launch_contract_path':str(out.resolve()),'launch_contract_sha256':contract['launch_contract_sha256'],'launch_command_sha256':contract['launch_command_sha256'],'engine_profile_sha256':contract['engine_profile_sha256'],'tensor_parallel_size':profile['tensor_parallel_size'],'historical_endpoint_or_alias_reused':False,'engine_profile_rediscovery_performed':False,'scientific_candidate_reselection_performed':False},indent=2,sort_keys=True))
    return 0

if __name__=='__main__': raise SystemExit(main())
