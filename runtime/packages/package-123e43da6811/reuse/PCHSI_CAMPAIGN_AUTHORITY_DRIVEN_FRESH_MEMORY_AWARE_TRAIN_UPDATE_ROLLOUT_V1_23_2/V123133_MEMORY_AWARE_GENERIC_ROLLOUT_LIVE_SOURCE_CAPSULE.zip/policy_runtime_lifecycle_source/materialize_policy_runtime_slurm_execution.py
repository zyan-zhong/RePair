#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, sys
from pathlib import Path
from policy_runtime_slurm_execution import load_cluster_policy, build_slurm_execution_contract, render_batch_script, build_sbatch_argv
from policy_runtime_engine_profile_receipt import validate_engine_profile_receipt
from policy_runtime_service import derive_runtime_authority, write_once


def _load(path):
    v=json.loads(Path(path).read_text('utf-8'))
    if not isinstance(v,dict): raise ValueError('JSON object required')
    return v


def main(argv=None):
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-integration-root',required=True); ap.add_argument('--retry-integration-root',required=True); ap.add_argument('--repo',required=True); ap.add_argument('--engine-profile',required=True); ap.add_argument('--launch-contract',required=True); ap.add_argument('--cluster-policy',required=True); ap.add_argument('--python',default=sys.executable); ap.add_argument('--output-dir',required=True); ap.add_argument('--service-ready-timeout-seconds',type=float,default=600); ap.add_argument('--branch-operational-timeout-seconds',type=int,default=3600); ap.add_argument('--termination-grace-seconds',type=int,default=30)
    a=ap.parse_args(argv)
    package_root=Path(__file__).resolve().parent; out=Path(a.output_dir).resolve()
    if out.exists() or out.is_symlink(): raise SystemExit('STOP=SLURM_EXECUTION_OUTPUT_EXISTS')
    out.mkdir(parents=True,mode=0o700)
    runtime=derive_runtime_authority(Path(a.source_integration_root).resolve())['runtime_binding']
    profile=validate_engine_profile_receipt(_load(a.engine_profile),runtime)
    launch=_load(a.launch_contract); policy=load_cluster_policy(a.cluster_policy)
    execution_contract=build_slurm_execution_contract(launch_contract=launch,engine_profile=profile,cluster_policy=policy,source_integration_root=a.source_integration_root,retry_integration_root=a.retry_integration_root,repo=a.repo,python_executable=a.python,package_root=str(package_root),launch_contract_path=a.launch_contract,execution_root=str(out),service_ready_timeout_seconds=a.service_ready_timeout_seconds,branch_operational_timeout_seconds=a.branch_operational_timeout_seconds,termination_grace_seconds=a.termination_grace_seconds)
    contract_path=out/'POLICY_RUNTIME_SLURM_F0F1_EXECUTION_CONTRACT_V1.json'; write_once(contract_path,execution_contract)
    script_path=out/'RUN_POLICY_RUNTIME_F0F1_COMPUTE.sbatch'; script_path.write_text(render_batch_script(str(Path(a.python).resolve()),str(package_root),str(contract_path)),'utf-8'); os.chmod(script_path,0o700)
    stdout_path=str(out/'slurm-%j.out'); stderr_path=str(out/'slurm-%j.err')
    submit_argv=build_sbatch_argv(execution_contract,str(script_path),stdout_path,stderr_path)
    plan={'schema_id':'POLICY_RUNTIME_SLURM_SUBMISSION_PLAN_V1','schema_version':1,'status':'READY_REQUIRES_EXPLICIT_CANARY_SUBMISSION_APPROVAL','execution_contract_path':str(contract_path),'execution_contract_sha256':execution_contract['execution_contract_sha256'],'batch_script_path':str(script_path),'submit_argv':submit_argv,'partition':execution_contract['partition'],'gpus':execution_contract['gpus'],'tensor_parallel_size':execution_contract['tensor_parallel_size'],'engine_profile_sha256':execution_contract['engine_profile_sha256'],'launch_contract_sha256':execution_contract['launch_contract_sha256'],'cluster_policy_sha256':execution_contract['cluster_policy_sha256'],'scientific_candidate_reselection_performed':False,'environment_execution_authorized':False}
    plan_path=out/'POLICY_RUNTIME_SLURM_SUBMISSION_PLAN_V1.json'; write_once(plan_path,plan)
    print(json.dumps(plan,indent=2,sort_keys=True)); return 0

if __name__=='__main__': raise SystemExit(main())
