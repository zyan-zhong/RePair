#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from policy_runtime_service import derive_runtime_authority, probe_policy_runtime_service, readiness_with_sha

def main(argv=None):
    ap=argparse.ArgumentParser(); ap.add_argument('--integration-root',required=True); ap.add_argument('--timeout-seconds',type=float,default=2.0); a=ap.parse_args(argv)
    authority=derive_runtime_authority(Path(a.integration_root))
    report=readiness_with_sha(probe_policy_runtime_service(authority,timeout_seconds=a.timeout_seconds))
    print(json.dumps(report,indent=2,sort_keys=True,ensure_ascii=False))
    return 0 if report['ready'] else 4
if __name__=='__main__': raise SystemExit(main())
