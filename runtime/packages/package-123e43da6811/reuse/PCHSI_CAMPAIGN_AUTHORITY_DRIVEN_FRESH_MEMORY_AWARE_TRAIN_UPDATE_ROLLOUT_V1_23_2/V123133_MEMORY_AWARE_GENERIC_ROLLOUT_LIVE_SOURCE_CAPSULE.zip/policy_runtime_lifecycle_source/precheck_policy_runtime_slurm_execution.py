#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil
from pathlib import Path
from policy_runtime_slurm_execution import validate_execution_contract


def main(argv=None):
    ap=argparse.ArgumentParser(); ap.add_argument('--execution-root',required=True); a=ap.parse_args(argv)
    root=Path(a.execution_root).resolve(); contract=json.loads((root/'POLICY_RUNTIME_SLURM_F0F1_EXECUTION_CONTRACT_V1.json').read_text('utf-8')); validate_execution_contract(contract)
    plan=json.loads((root/'POLICY_RUNTIME_SLURM_SUBMISSION_PLAN_V1.json').read_text('utf-8'))
    report={'schema_id':'POLICY_RUNTIME_SLURM_EXECUTION_PREFLIGHT_V1','schema_version':1,'status':None,'sbatch_path':shutil.which('sbatch'),'sacct_path':shutil.which('sacct'),'partition':contract['partition'],'gpus':contract['gpus'],'tensor_parallel_size':contract['tensor_parallel_size'],'gpu_count_matches_tensor_parallel':contract['gpus']==contract['tensor_parallel_size'],'same_allocation_service_and_f0f1_required':contract['same_allocation_service_and_f0f1_required'],'compile_node_gpu_execution_forbidden':contract['compile_node_gpu_execution_forbidden'],'execution_contract_sha256':contract['execution_contract_sha256'],'environment_execution_authorized':False,'scientific_candidate_reselection_performed':False}
    if report['sbatch_path'] is None: report['status']='SBATCH_NOT_AVAILABLE'
    elif report['sacct_path'] is None: report['status']='SACCT_NOT_AVAILABLE'
    elif plan.get('status')!='READY_REQUIRES_EXPLICIT_CANARY_SUBMISSION_APPROVAL': report['status']='SUBMISSION_PLAN_INVALID'
    else: report['status']='READY_REQUIRES_EXPLICIT_SLURM_CANARY_SUBMISSION_APPROVAL'
    print(json.dumps(report,indent=2,sort_keys=True)); return 0 if report['status']=='READY_REQUIRES_EXPLICIT_SLURM_CANARY_SUBMISSION_APPROVAL' else 4

if __name__=='__main__': raise SystemExit(main())
