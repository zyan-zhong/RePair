#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from policy_runtime_service import derive_runtime_authority, write_once
from policy_runtime_engine_profile import discover_compatible_engine_profile


def main(argv=None):
    ap=argparse.ArgumentParser()
    ap.add_argument('--integration-root', required=True)
    ap.add_argument('--search-root', action='append', required=True)
    ap.add_argument('--max-candidate-json-files', type=int, default=4096)
    ap.add_argument('--max-walked-json-files', type=int, default=250000)
    ap.add_argument('--write-receipt')
    a=ap.parse_args(argv)
    runtime=derive_runtime_authority(Path(a.integration_root))['runtime_binding']
    report=discover_compatible_engine_profile(runtime,[Path(x) for x in a.search_root],max_candidate_json_files=a.max_candidate_json_files,max_walked_json_files=a.max_walked_json_files)
    print(json.dumps(report,indent=2,sort_keys=True,ensure_ascii=False))
    if a.write_receipt:
        target=Path(a.write_receipt)
        if target.exists() or target.is_symlink(): raise SystemExit('STOP=ENGINE_PROFILE_RECEIPT_EXISTS')
        write_once(target,report)
    return 0 if report['status']=='RESOLVED_UNIQUE_COMPATIBLE_POLICY_ENGINE_PROFILE' else 4

if __name__=='__main__': raise SystemExit(main())
