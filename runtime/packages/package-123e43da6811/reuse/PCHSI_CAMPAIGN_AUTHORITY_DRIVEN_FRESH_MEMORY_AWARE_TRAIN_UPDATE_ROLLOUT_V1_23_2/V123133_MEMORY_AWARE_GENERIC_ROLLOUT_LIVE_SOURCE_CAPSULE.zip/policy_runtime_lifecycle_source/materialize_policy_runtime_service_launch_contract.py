#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from policy_runtime_service import derive_runtime_authority, write_once
from policy_runtime_engine_profile import discover_compatible_engine_profile, build_current_runtime_service_launch_contract


def main(argv=None):
    ap=argparse.ArgumentParser()
    ap.add_argument('--integration-root', required=True)
    ap.add_argument('--search-root', action='append', required=True)
    ap.add_argument('--python', default=sys.executable)
    ap.add_argument('--max-candidate-json-files', type=int, default=4096)
    ap.add_argument('--max-walked-json-files', type=int, default=250000)
    ap.add_argument('--output', required=True)
    a=ap.parse_args(argv)
    runtime=derive_runtime_authority(Path(a.integration_root))['runtime_binding']
    profile=discover_compatible_engine_profile(runtime,[Path(x) for x in a.search_root],max_candidate_json_files=a.max_candidate_json_files,max_walked_json_files=a.max_walked_json_files)
    if profile.get('status')!='RESOLVED_UNIQUE_COMPATIBLE_POLICY_ENGINE_PROFILE':
        print(json.dumps(profile,indent=2,sort_keys=True,ensure_ascii=False)); return 4
    contract=build_current_runtime_service_launch_contract(runtime,profile,python_executable=a.python)
    out=Path(a.output)
    if out.exists() or out.is_symlink(): raise SystemExit('STOP=POLICY_RUNTIME_SERVICE_LAUNCH_CONTRACT_EXISTS')
    write_once(out,contract)
    print(json.dumps({'status':contract['status'],'launch_contract_path':str(out.resolve()),'launch_contract_sha256':contract['launch_contract_sha256'],'launch_command_sha256':contract['launch_command_sha256'],'engine_profile_sha256':contract['engine_profile_sha256'],'historical_endpoint_or_alias_reused':False,'operator_launch_knobs_synthesized':False,'scientific_candidate_reselection_performed':False},indent=2,sort_keys=True))
    return 0

if __name__=='__main__': raise SystemExit(main())
