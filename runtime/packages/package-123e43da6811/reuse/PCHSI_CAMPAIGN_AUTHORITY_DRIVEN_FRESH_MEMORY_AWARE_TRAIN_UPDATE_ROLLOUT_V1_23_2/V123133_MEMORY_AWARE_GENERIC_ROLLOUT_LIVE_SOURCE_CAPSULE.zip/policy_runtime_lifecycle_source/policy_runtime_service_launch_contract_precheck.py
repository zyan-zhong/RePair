#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, subprocess, sys
from pathlib import Path


def main(argv=None):
    ap=argparse.ArgumentParser(); ap.add_argument('--launch-contract',required=True); ap.add_argument('--python',default=sys.executable); a=ap.parse_args(argv)
    p=Path(a.launch_contract).resolve(); value=json.loads(p.read_text('utf-8'))
    if value.get('status')!='MATERIALIZED_CURRENT_RUNTIME_SERVICE_LAUNCH_CONTRACT': raise SystemExit('STOP=LAUNCH_CONTRACT_STATUS_INVALID')
    cp=subprocess.run([a.python,'-c','import vllm; print(vllm.__version__)'],capture_output=True,text=True,check=False)
    observed=cp.stdout.strip() if cp.returncode==0 else None
    model_path=Path(str(value.get('base_model_local_path')))
    report={'schema_id':'POLICY_RUNTIME_SERVICE_LAUNCH_CONTRACT_PREFLIGHT_V1','schema_version':1,'status':None,'python':a.python,'vllm_import_rc':cp.returncode,'expected_vllm_version':value.get('vllm_version'),'observed_vllm_version':observed,'model_path_exists':model_path.is_dir(),'launch_contract_sha256':value.get('launch_contract_sha256'),'environment_execution_authorized':False,'scientific_model_calls':0,'training_executions':0}
    if cp.returncode!=0: report['status']='PYTHON_VLLM_IMPORT_NOT_READY'
    elif observed!=value.get('vllm_version'): report['status']='VLLM_VERSION_MISMATCH'
    elif not model_path.is_dir(): report['status']='BOUND_MODEL_PATH_NOT_READY'
    else: report['status']='READY_FOR_GPU_HOST_POLICY_SERVICE_LIFECYCLE'
    print(json.dumps(report,indent=2,sort_keys=True)); return 0 if report['status']=='READY_FOR_GPU_HOST_POLICY_SERVICE_LIFECYCLE' else 4

if __name__=='__main__': raise SystemExit(main())
