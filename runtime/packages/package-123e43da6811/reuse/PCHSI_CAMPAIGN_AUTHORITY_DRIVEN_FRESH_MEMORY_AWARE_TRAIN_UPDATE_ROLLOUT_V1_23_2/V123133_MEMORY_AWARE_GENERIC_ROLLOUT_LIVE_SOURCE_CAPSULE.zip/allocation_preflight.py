from __future__ import annotations

from collections.abc import Mapping
import hashlib
import json


def _canon(value: object) -> bytes:
    return (
        json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        )
        + "\n"
    ).encode("utf-8")


def build_allocation_preflight_contract(
    slurm_plan: Mapping[str, object],
) -> dict[str, object]:
    if (
        slurm_plan.get("schema_id")
        != "ROUND_MEMORY_AWARE_GENERIC_ROLLOUT_SLURM_RESOURCE_PLAN_V1"
    ):
        raise ValueError("SLURM_PLAN_SCHEMA")
    for field in ("partition", "gpus", "nodes", "ntasks"):
        if field not in slurm_plan:
            raise ValueError("SLURM_PLAN_MISSING_" + field.upper())
    if type(slurm_plan["gpus"]) is not int or slurm_plan["gpus"] <= 0:
        raise ValueError("SLURM_PLAN_GPUS")
    if type(slurm_plan["nodes"]) is not int or slurm_plan["nodes"] <= 0:
        raise ValueError("SLURM_PLAN_NODES")
    if type(slurm_plan["ntasks"]) is not int or slurm_plan["ntasks"] <= 0:
        raise ValueError("SLURM_PLAN_NTASKS")
    if not isinstance(slurm_plan["partition"], str) or not slurm_plan["partition"]:
        raise ValueError("SLURM_PLAN_PARTITION")

    payload = {
        "schema_id": "ROUND_MEMORY_AWARE_GENERIC_ROLLOUT_ALLOCATION_PREFLIGHT_V1",
        "schema_version": 1,
        "expected_partition": slurm_plan["partition"],
        "expected_gpus": slurm_plan["gpus"],
        "expected_nodes": slurm_plan["nodes"],
        "expected_ntasks": slurm_plan["ntasks"],
        "partition_authority": slurm_plan.get("partition_authority"),
        "gpu_count_authority": slurm_plan.get("gpu_count_authority"),
        "required_slurm_environment": [
            "SLURM_JOB_ID_OR_JOBID",
            "SLURM_JOB_PARTITION",
            "SLURM_JOB_NODELIST",
            "SLURM_GPUS_ON_NODE",
        ],
        "required_runtime_checks": [
            "torch.cuda.device_count",
            "CUDA_VISIBLE_DEVICES_CARDINALITY_IF_PRESENT",
        ],
        "service_launch_after_preflight_only": True,
        "fail_closed_on_gpu_count_mismatch": True,
        "fail_closed_on_partition_mismatch": True,
        "scientific_execution_authorized": False,
        "contract_sha256": "0" * 64,
    }
    payload["contract_sha256"] = hashlib.sha256(
        b"ROUND_MEMORY_AWARE_GENERIC_ROLLOUT_ALLOCATION_PREFLIGHT_V1\0"
        + _canon({k: v for k, v in payload.items() if k != "contract_sha256"})
    ).hexdigest()
    return payload


def _visible_device_count(value: str) -> int:
    tokens = [part.strip() for part in value.split(",") if part.strip()]
    return len(tokens)


def validate_live_allocation(
    contract: Mapping[str, object],
    env: Mapping[str, str],
    *,
    cuda_device_count: int,
) -> dict[str, object]:
    if (
        contract.get("schema_id")
        != "ROUND_MEMORY_AWARE_GENERIC_ROLLOUT_ALLOCATION_PREFLIGHT_V1"
    ):
        raise ValueError("ALLOCATION_PREFLIGHT_SCHEMA")
    job_id = env.get("SLURM_JOB_ID") or env.get("SLURM_JOBID")
    if not job_id:
        raise ValueError("SLURM_JOB_ID_MISSING")
    if env.get("SLURM_JOB_PARTITION") != contract.get("expected_partition"):
        raise ValueError("SLURM_PARTITION_MISMATCH")
    if not env.get("SLURM_JOB_NODELIST"):
        raise ValueError("SLURM_NODELIST_MISSING")

    expected = contract.get("expected_gpus")
    if type(expected) is not int or expected <= 0:
        raise ValueError("EXPECTED_GPU_COUNT_INVALID")
    raw_gpus_on_node = env.get("SLURM_GPUS_ON_NODE")
    if raw_gpus_on_node is None:
        raise ValueError("SLURM_GPUS_ON_NODE_MISSING")
    try:
        allocated = int(raw_gpus_on_node)
    except ValueError as exc:
        raise ValueError("SLURM_GPUS_ON_NODE_INVALID") from exc
    if allocated != expected:
        raise ValueError("SLURM_ALLOCATED_GPU_COUNT_MISMATCH")

    if type(cuda_device_count) is not int or cuda_device_count != expected:
        raise ValueError("CUDA_DEVICE_COUNT_MISMATCH")

    visible = env.get("CUDA_VISIBLE_DEVICES")
    if visible is not None and _visible_device_count(visible) != expected:
        raise ValueError("CUDA_VISIBLE_DEVICES_CARDINALITY_MISMATCH")

    return {
        "schema_id": "ROUND_MEMORY_AWARE_GENERIC_ROLLOUT_ALLOCATION_PREFLIGHT_RESULT_V1",
        "schema_version": 1,
        "job_id": job_id,
        "partition": env["SLURM_JOB_PARTITION"],
        "node_list": env["SLURM_JOB_NODELIST"],
        "slurm_gpus_on_node": allocated,
        "cuda_device_count": cuda_device_count,
        "cuda_visible_devices": visible,
        "ready_for_service_launch": True,
        "scientific_execution_authorized": False,
        "human_selection_performed": False,
    }
